# SchoolCensorshipAnalysis

An analysis on school censhorship on 2022 with INEP data.
The main purpose of this project is filter cities and group at least two variables with focus in pertinent analysis.

Also, create graphics to analyze the data from INEP (National Institute of Educational Studies and Research).


